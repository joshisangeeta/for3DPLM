package com.cp1;
import com.cp2.MsgUtil;
public class Main {
   public static void main(String[] args) {
	MsgUtil ob = new MsgUtil();
	System.out.println(ob.getMsg());
   }
} 