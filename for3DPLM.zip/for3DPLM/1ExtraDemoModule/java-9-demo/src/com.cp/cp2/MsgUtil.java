package com.cp2;
public class MsgUtil {
   public String getMsg() {
	   return "Hello World!";
   }
} 