/**
 * 
 */

/**
 * @author sangeeta
 *
 */
public class VarDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	      var  x =new Integer("5");
	      
	
	      String      x1 =new String("abc");
	
	
	
	
	 }

}

//interface 
