/**
 * 
 */
package com.sj.io;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

/**
 * @author sangeeta
 *
 */
public class FileReadWrite {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Path filePath = Paths.get("F:\\Demos\\Core Java\\JavaVersions\\Java 11\\files", "temp", "test.txt");
		 
        try
        {
            //Write content to file
            Files.writeString(filePath, "Hello World !!", StandardOpenOption.APPEND);
 
            //Verify file content
            String content = Files.readString(filePath);
 
            System.out.println(content);
            
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
	
	
	
	   // Java 7 :-
	/*
	String content = "Hello World \r\nJava!\r\n";
    String path = "c:\\projects\\app.log";
	
    try {

        // Java 7
        Files.write(Paths.get(path), content.getBytes());

        // encoding
        // Files.write(Paths.get(path), content.getBytes(StandardCharsets.UTF_8));

        // extra options
        // Files.write(Paths.get(path), content.getBytes(), 
		//		StandardOpenOption.CREATE, StandardOpenOption.APPEND);

    } catch (IOException e) {
        e.printStackTrace();
    }
	      */
	
	
	 /*
	   public static void main(String[] args)
    {
        Path filePath = Paths.get("C:/", "temp", "test.txt");
 
        try
        {
            String content = Files.readString(filePath);
 
            System.out.println(content);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
	   
	
	*/

}
