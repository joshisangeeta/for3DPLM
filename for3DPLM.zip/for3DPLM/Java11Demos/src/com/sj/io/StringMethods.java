/**
 * 
 */
package com.sj.io;

/**
 * @author sangeeta
 *
 */
public class StringMethods {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	             // isBlank
	
		    System.out.println( "ABC".isBlank() );          //false
		 
	        System.out.println( " ABC ".isBlank() );        //false
	 
	        System.out.println( "  ".isBlank() );           //true
	 
	        System.out.println( "".isBlank() );             //true
	
	         // isBlank vs isEmpty
	
	        System.out.println( "ABC".isBlank() );      //false
	        System.out.println( "  ".isBlank() );       //true
	 
	        System.out.println( "ABC".isEmpty() );      //false
	        System.out.println( "    ".isEmpty() );       //false
	        System.out.println( "".isEmpty() );           //true
	          
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
