/**
 * 
 */
package com.sj.io;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.stream.Stream;

/**
 * @author sangeeta
 *
 */
public class StringMethods2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
		   try
	        {
	            Path file = Files.createTempFile("testOne", ".txt");
	 
	            //Write contents to file
	            Files.writeString(file, "ABC\n", StandardOpenOption.APPEND);
	            Files.writeString(file, "123\n", StandardOpenOption.APPEND);
	            Files.writeString(file, "XYZ", StandardOpenOption.APPEND); 
	 
	            Stream<String> lines = Files.lines(file);
	 
	            lines.forEach(System.out::println);
	        }
	        catch (IOException e)
	        {
	            e.printStackTrace();
	        }
	 
		
		
		
		
		
		
		
	}

}
