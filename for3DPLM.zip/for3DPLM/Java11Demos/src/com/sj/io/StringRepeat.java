/**
 * 
 */
package com.sj.io;

/**
 * @author sangeeta
 *
 */
public class StringRepeat {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Abc";
		 
        System.out.println( str.repeat(3) );
	
	
	
	
	}

}
