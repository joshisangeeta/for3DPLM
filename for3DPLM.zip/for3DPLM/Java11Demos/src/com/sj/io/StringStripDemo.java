/**
 * 
 */
package com.sj.io;

/**
 * @author sangeeta
 *
 */
public class StringStripDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		     String str = "  Hello World !!   ";
		  
	        System.out.println( str.strip() );          //"Hello World !!"
	 
	        System.out.println( str.stripLeading() );   //"Hello World !!   "
	 
	        System.out.println( str.stripTrailing() );  //"  Hello World !!"
	
	
	
	
	
	}

}
