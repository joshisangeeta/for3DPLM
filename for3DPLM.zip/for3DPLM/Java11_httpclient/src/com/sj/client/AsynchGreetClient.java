/**
 * 
 */
package com.sj.client;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.ExecutionException;

/**
 * @author sangeeta
 *
 */
public class AsynchGreetClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	  
		var client = HttpClient.newHttpClient();

		var request = HttpRequest.newBuilder().GET().uri(URI.create("http://localhost:8080/ServerForHttpClient/GreetServlet")).build();
		
		
		var future = client.sendAsync(request, HttpResponse.BodyHandlers.ofString());

		String body2 = null;
		try {
			body2 = future.thenApply(HttpResponse::body).get();
		
		
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(body2);
	
	    System.out.println("in main");
	
	
	
	
	
	}

}
