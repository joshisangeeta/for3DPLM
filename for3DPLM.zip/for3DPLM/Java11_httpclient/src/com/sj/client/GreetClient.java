/**
 * 
 */
package com.sj.client;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 * @author sangeeta
 *
 */
public class GreetClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		var client = HttpClient.newHttpClient();

		var request = HttpRequest.newBuilder().GET().uri(URI.create("http://localhost:8080/ServerForHttpClient/GreetServlet")).build();
		
		
				HttpResponse<String> response = null;
				try {
					response = client.send(request, HttpResponse.BodyHandlers.ofString());
				} catch (IOException | InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		String body = response.body();

		System.out.println(body);
		
		System.out.println("client-side- response received");
		

	}

}
