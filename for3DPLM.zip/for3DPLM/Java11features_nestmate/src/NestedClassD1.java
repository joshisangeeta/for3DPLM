/**
 * 
 */

/**
 * @author sangeeta
 *
 */
public class NestedClassD1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

	   new Outer1().new Inner().printOuterInt();
	
	}	
		
}
 class Outer1{
		    private int outerInt;
		    
		    class Inner {
		       public void printOuterInt() {
		         System.out.println("Outer int = " + outerInt);
		                          }
		          }
	   }
	
	
// Internally 
 /*
     class Inner$Outer {
      Outer outer;
      public void printOuterInt() {
        System.out.println("Outer int = " + outer.access$000());
      }
    }
	
	
	*/
	
	

