import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;



/**
 * 
 */

/**
 * @author sangeeta
 *
 */
public class NestedClassDemo {

      public static void main(String[] args) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    	  
    	  Outer out = new Outer();
    	 Outer.Inner inner =new Outer().new Inner ();
    	 
    	 inner.innerReflectionAccess(out);
    	 System.out.println("hello");
    	 
      }
}

class Outer{
	
	public void outerPublic() {
		
	}	
	private void outerPrivate() {
		
	}	
	class Inner{
		
	public void innerPublic() {
		
		outerPrivate();
		
	}	
	/*
	A further consequence of this is that core reflection also denies access. This is surprising given that reflective invocations should behave the same as source level invocations.

         For example, if we try to call the outerPrivate() reflectively from the Inner class:
	*/
	public void innerReflectionAccess(Outer o) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
	      Method method = o.getClass().getDeclaredMethod("outerPrivate");
	            method.invoke(o);
	
	}
	
	
	
	}	
	
	
	
}
