package com.sj;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/**
 * 
 */

/**
 * @author sangeeta
 *
 */

public class MethodRefDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] symbols = { "GOOG.NS", "APPL.NS", "MSFT.NS", "AMZN.NS"}; 
		Arrays.sort(symbols, String::compareToIgnoreCase); 
		
		System.out.println(symbols);
		
		Predicate<Integer> isOdd = n -> IntPredicates.isOdd(n);
		Predicate<Integer> isEven = n -> IntPredicates.isEven(n);
	
		Predicate<Integer> isOdd1 =  IntPredicates::isOdd;
		Predicate<Integer> isEven1 = IntPredicates::isEven;
	
	
		
		
		
	     
	}
	
	
	
	static class IntPredicates {
		public static boolean isOdd(Integer n) { return n % 2 != 0; }
		public static boolean isEven(Integer n) { return n % 2 == 0; }
		public static boolean isPositive(Integer n) { return n >= 0; }
		}
	

}
