/**
 * 
 */
package com.sj;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * @author sangeeta
 *
 */
public class StreamDemo2 {

	/**
	 * @param args
	 */
	
	private static long counter;
	  
	private static void wasCalled() {
	    counter++;
	    System.out.println(counter);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	      //1.
		
		/*
		 * List<String> list = Arrays.asList("abc1","abc2","abc3"); counter = 0;
		 * Stream<String> stream = list.stream().filter(element -> { wasCalled(); return
		 * element.contains("2"); });
		 */
		  
		   //2.
		  List<String> list = Arrays.asList("abc1","abc2","abc3"); 
		  Optional<String> stream = list.stream().filter(element -> {
		       System.out.println(("filter() was called")); 
		       return element.contains("2");
		  }).map(element -> { 
			  
			  System.out.println(("map() was called"));
		  
		        return element.toUpperCase(); }).findFirst();
		 
	
	
	}

}
