/**
 * 
 */
package com.sj.modules;

/**
 * @author sangeeta
 *
 */
public class Greet {
	
	
	
	     public void sayHello() {
	    	 System.out.println("Hello world...");
	     }
	

}
