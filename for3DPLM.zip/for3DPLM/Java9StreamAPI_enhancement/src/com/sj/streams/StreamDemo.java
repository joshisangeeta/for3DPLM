/**
 * 
 */
package com.sj.streams;

import java.util.stream.Stream;

/**
 * @author sangeeta
 *
 */
public class StreamDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	         //Java 8 filter method :
		
		System.out.println("filter");
		
		Stream.of("a","b","","c").filter(s->!s.isEmpty()).forEach(System.out::print);
		
			   //Java 9  takeWhile
	//	System.out.println("-------");
		System.out.println("take while");
	
    	Stream.of("a","b","","c").takeWhile(s->!s.isEmpty()).forEach(System.out::print);
	
	 // Java 9 dropWhile
	System.out.println("-------");
		System.out.println("dropwhile -1");
		Stream.of("a","b","","c").dropWhile(s->!s.isEmpty()).forEach(System.out::print);
		System.out.println("-------");
		System.out.println("dropwhile -2");
		Stream.of("a","b","","c","","d").dropWhile(s->!s.isEmpty()).forEach(System.out::print);
	
	}

}
