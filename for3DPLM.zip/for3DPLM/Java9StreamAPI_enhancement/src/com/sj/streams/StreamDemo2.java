/**
 * 
 */
package com.sj.streams;

import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @author sangeeta
 *
 */
public class StreamDemo2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	    //earlier version will never stop
        Stream.iterate(1,count->count+2).forEach(System.out::println);
		
		
		// java 9
		IntStream.iterate(3,x->x<10,x->x+3).forEach(System.out::println);
	
	
	
	
	}

	
}
