/**
 * 
 */
package trials;

import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * @author sangeeta
 *
 */
public class Demo1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Consumer <String> consumer=(str)->System.out.println(str);
	consumer.accept("hello world");
	
	Supplier <String> supplier = ()->"hi java 8";
	
	consumer.accept(supplier.get());
	
	Predicate <Integer> predicate = num->num%2==0;
	System.out.println(predicate.test(5));
	
	Consumer <Integer>consumer1 =(num)->System.out.println(num*num);
	
	      consumer1.accept(4);
	      
	  //  Method reference  Consumer <String> consumer2=(str)->System.out.println(str);
	//Consumer <String>consumer2 = System.out :: println;
	
	  //     consumer2.accept("through method ref");
	
	
	
	
	}
	
	
	
	

}
