/**
 * 
 */
package com.sj;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * @author sangeeta
 *
 */
public class CollectionDemoProblem {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 //Problem at hand : Creating a small immutable Collection
		
	  //approach 1  - for set & map
		
		Set<String> set = new HashSet<>();
		set.add("foo");
		set.add("bar");
		set.add("baz");
		set = Collections.unmodifiableSet(set);
	
	  //That's way too much code for a simple task and it should be possible to be done in a single expression.The is also true for a Map
	 
		          //- for list
	
	
	
	//approach 2  - double-brace technique
		Set<String> set1 = Collections.unmodifiableSet(new HashSet<String>() {{
		    add("foo"); add("bar"); add("baz");
		}});
	
	// approach 3 Using Java 8 streams
		/*
		 * Stream.of("foo", "bar", "baz") .collect(collectingAndThen(toSet(),
		 * Collections::unmodifiableSet));
		 */
	
	/*
	 * The Java 8 version, though, is a one-line expression, has some problems too. First, it's not obvious and intuitive, second, it's still verbose, third, it involves the creation of unnecessary objects and fourth, this method can't be used for creating a Map.

       To summarize the shortcomings, none of the above approaches treat the specific use case creating a small unmodifiable Collection first-class class problem.
	 * */
	
		List<String> list = Arrays.asList("foo", "bar", "baz");
		//Although this List creation is better than the constructor initialization, this is less obvious as the common intuition would not be to look into Arrays class for methods to create a List:
	
	}

}
