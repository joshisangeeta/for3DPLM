/**
 * 
 */
package com.sj;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author sangeeta
 *
 */
public class CollectionDemoSolution {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> list = List.of("foo", "bar", "baz");
		
		Set<String> set = Set.of("foo", "bar", "baz");
	
		//Passing in duplicate values for Key would throw an IllegalArgumentException:
		Map<String, String> map = Map.of("foo", "a", "bar", "b", "baz", "c");
	
	
	    System.out.println("List:"+list);
	    System.out.println("Set:"+set);
	    System.out.println("Map:"+map);
	
	}

}
