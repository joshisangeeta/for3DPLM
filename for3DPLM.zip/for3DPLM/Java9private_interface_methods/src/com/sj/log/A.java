/**
 * 
 */
package com.sj.log;

/**
 * @author sangeeta
 *
 */
public class A implements TryInterface {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	 A a = new A();
	
	   a.m2();
	   
	
	}

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
		int x = m2();
		System.out.println(x);
		
		System.out.println("m1");
	
	}

}
