/**
 * 
 */
package com.sj.log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author sangeeta
 *
 */
public interface Logger {

	String uname = "ABC_Mongo_Datastore";
	String password = "ABC_Neo4J_Datastore";
	String driver = "ABC_Cassandra_Datastore";
	String url="";
	

	default void logInfo(String message) {
		//getStatement().setString()
		
		log(message, "INFO");
	}

	default void logWarn(String message) {
		log(message, "WARN");
	}

	default void logError(String message) {
		log(message, "ERROR");
	}

	default void logFatal(String message) {
		log(message, "FATAL");
	}
	
	//private void log

	private PreparedStatement log(String message, String msgPrefix) {

		 PreparedStatement pst = null ;
	      try {
	    	 
			      Class.forName(driver);
			
			      Connection con = DriverManager.getConnection(url,uname,password);
			   pst   = con.prepareStatement("insert into logt value(?,?)");
			      return pst;
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	          return pst;
	
	 
	
	
	}







}
