/**
 * 
 */
package com.sj.log;

/**
 * @author sangeeta
 *
 */
@FunctionalInterface
public interface TryInterface {

   public void m1();
   
   default int m2() {
	   System.out.println(m4());
	   
     System.out.println("m1");
     return m4();
   }

    default void m3() {
    	
    	System.out.println(m4());
    	
    	System.out.println("m2");

  }
    
    
    private int m4() {
    	
    	
    	return 13;
    }
}
