/**
 * 
 */
package com.sj.hello.client;

import com.sj.hello.HelloWorld;

/**
 * @author sangeeta
 *
 */
public class HelloWorldClient {
	
	
	 public static void main (String arg[]) {

		    HelloWorld hello = new HelloWorld();
		    System.out.println(hello.sayHelloWorld());
			
		  }
	

}
