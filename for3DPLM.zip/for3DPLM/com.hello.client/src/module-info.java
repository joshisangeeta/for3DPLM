/**
 * 
 */
/**
 * @author sangeeta
 *
 */
module com.hello.client {
	
	requires com.hello;
	
	
}