module com.hello {
	 exports com.sj.hello;
}