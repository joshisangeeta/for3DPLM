module com.sj.hello.client {
	
	requires com.sj.hello;
}