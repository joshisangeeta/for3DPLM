/**
 * 
 */
package com.sj.hello;

/**
 * @author sangeeta
 *
 */
public class HelloWorld {

	
		  public String sayHelloWorld() {

		      return "Hello World!";
		  }

}
