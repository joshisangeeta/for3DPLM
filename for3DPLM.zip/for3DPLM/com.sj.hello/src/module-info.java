/**
 * 
 */
/**
 * @author sangeeta
 *
 */
module com.sj.hello {
	exports com.sj.hello.client;
	exports com.sj.hello;
}